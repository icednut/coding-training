// Package effects provides additional audio effects for the Beep library.
package effects
