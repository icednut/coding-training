// Package flac implements audio data decoding in FLAC format.
//
// Note: Seek method is still unimplemented.
package flac
