// Package text implements efficient text drawing for the Pixel library.
package text
