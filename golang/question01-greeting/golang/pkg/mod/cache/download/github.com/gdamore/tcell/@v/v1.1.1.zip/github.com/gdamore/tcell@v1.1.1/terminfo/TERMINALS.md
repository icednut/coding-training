TERMINALS
=========

The best way to populate terminals on Debian is to install ncurses,
ncurses-term, screen, tmux, rxvt-unicode, and dvtm.  This populates the
the terminfo database so that we can have a reasonable set of starting
terminals.
